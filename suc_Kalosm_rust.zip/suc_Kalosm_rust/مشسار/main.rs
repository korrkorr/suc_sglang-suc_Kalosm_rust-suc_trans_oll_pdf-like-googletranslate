use kalosm::language::*;
use std::path::PathBuf;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let model = Llama::builder()
        .with_source(
            LlamaSource::llama_3_1_8b_chat()
                .with_cache(kalosm_common::Cache::new(
                    PathBuf::from("/home/m/Desktop/Kalosm_rust/models")
                ))
        )  // ← هذا القوس كان ناقصاً
        .build()
        .await?;

    let mut chat = model
        .chat()
        .with_system_prompt("You are a helpful assistant");

    loop {
        chat(&prompt_input("\n> ")?).to_std_out().await?;
    }
}
