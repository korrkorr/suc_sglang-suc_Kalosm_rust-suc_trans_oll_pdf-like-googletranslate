use kalosm::language::*;
use std::path::PathBuf;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let model = Llama::builder()
        .with_source(
            LlamaSource::phi_3_5_mini_4k_instruct()  // ← tokenizer وconfig خاص بـ Phi
                .with_model(FileSource::Local(PathBuf::from(
                    "/home/m/Desktop/Kalosm_rust/next-gen-ai/Phi-3.1-mini-128k-instruct-Q4_K_M.gguf"
                )))
        )
        .build()
        .await?;

    let mut chat = model
        .chat()
        .with_system_prompt("You are a helpful assistant");

    loop {
        chat(&prompt_input("\n> ")?).to_std_out().await?;
    }
}
