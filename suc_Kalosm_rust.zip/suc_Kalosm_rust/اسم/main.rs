use kalosm::language::*;
use std::path::PathBuf;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let model = Llama::builder()
        .with_source(
            LlamaSource::llama_3_1_8b_chat()  // ← غيّر النموذج هنا
        )
        .build()
        .await?;

    let mut chat = model
        .chat()
        .with_system_prompt("The assistant will act like a pirate");

    loop {
        chat(&prompt_input("\n> ")?).to_std_out().await?;
    }
}
