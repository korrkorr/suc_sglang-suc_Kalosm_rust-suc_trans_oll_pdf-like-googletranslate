use kalosm::language::*;
use std::path::PathBuf;

#[tokio::main]
async fn main() {
    let source = LlamaSource::phi_3_5_mini_4k_instruct()
        .with_model(FileSource::Local(PathBuf::from(
            "/home/m/Desktop/Kalosm_rust/next-gen-ai/Phi-3.1-mini-128k-instruct-Q4_K_M.gguf"
        )));

    let model = Llama::builder()
        .with_source(source)
        .build()
        .await
        .unwrap();

    let mut chat = model.chat();

    loop {
        let message = prompt_input("\n> ").unwrap();
        let mut response = chat(&message);
        response.to_std_out().await.unwrap();
    }
}
