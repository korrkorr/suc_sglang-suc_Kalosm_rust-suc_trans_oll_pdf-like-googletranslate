use kalosm::language::*;
use std::path::PathBuf;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let model = Llama::builder()
        .with_source(
            LlamaSource::llama_3_1_8b_chat()
                .with_model(FileSource::HuggingFace {
                    model_id: "lmstudio-community/Meta-Llama-3.1-8B-Instruct-GGUF".to_string(),
                    revision: "main".to_string(),
                    file: "Meta-Llama-3.1-8B-Instruct-Q8_0.gguf".to_string(), // ← غيّر هنا
                })
                .with_cache(kalosm_common::Cache::new(
                    PathBuf::from("/home/m/Desktop/Kalosm_rust/models")
                ))
        )
        .build()
        .await?;

    let mut chat = model
        .chat()
        .with_system_prompt("You are a helpful assistant");

    loop {
        chat(&prompt_input("\n> ")?).to_std_out().await?;
    }
}
